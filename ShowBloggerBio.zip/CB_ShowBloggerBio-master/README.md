CB_ShowBloggerBio
=================

ContentBox Module to automatically include the author bio in blog posts